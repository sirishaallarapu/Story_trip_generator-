import React, { useState } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import './TripForm.css';

const TripForm = ({ onSubmit }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    destination: '',
    trip_type: '',
    start_date: null,
    end_date: null,
    food_preference: 'vegetarian',
    num_members: 1,
    budget: 50000,
  });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleDateChange = (dates) => {
    const [start, end] = dates;
    setFormData({ ...formData, start_date: start, end_date: end });
    if (start && end) {
      const duration = Math.ceil((end - start) / (1000 * 60 * 60 * 24)) + 1;
      setFormData({ ...formData, start_date: start, end_date: end, duration });
    }
  };

  const validateStep = () => {
    switch (step) {
      case 1:
        if (!formData.destination.trim()) {
          setError('Destination is required.');
          return false;
        }
        break;
      case 2:
        if (!formData.trip_type) {
          setError('Trip type is required.');
          return false;
        }
        break;
      case 3:
        if (!formData.start_date || !formData.end_date) {
          setError('Please select both start and end dates.');
          return false;
        }
        if (formData.duration < 1) {
          setError('Trip duration must be at least 1 day.');
          return false;
        }
        break;
      case 4:
        if (!formData.food_preference) {
          setError('Food preference is required.');
          return false;
        }
        break;
      case 5:
        if (formData.num_members < 1) {
          setError('Number of members must be at least 1.');
          return false;
        }
        if (formData.budget <= 0) {
          setError('Budget must be positive.');
          return false;
        }
        break;
      default:
        return true;
    }
    setError(null);
    return true;
  };

  const nextStep = () => {
    if (validateStep()) {
      setStep(step + 1);
      setError(null);
    }
  };

  const prevStep = () => {
    setStep(step - 1);
    setError(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateStep()) return;

    setLoading(true);
    setError(null);

    try {
      const payload = {
        destination: formData.destination,
        trip_type: formData.trip_type,
        duration: formData.duration,
        food_preference: formData.food_preference,
        num_members: parseInt(formData.num_members),
        budget: parseFloat(formData.budget),
      };

      const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:8000';
      const res = await axios.post(`${apiUrl}/api/trip`, payload, {
        timeout: 90000,
      });

      console.log('API response:', res.data);
      onSubmit(res.data, formData);
      setStep(1); // Reset to first page
      setFormData({
        destination: '',
        trip_type: '',
        start_date: null,
        end_date: null,
        food_preference: 'vegetarian',
        num_members: 1,
        budget: 50000,
      });
    } catch (err) {
      setError(err.response?.data?.detail || err.message || 'An error occurred.');
      console.error('Request error:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div>
            <h3 className="page-title">Where are you traveling?</h3>
            <div className="form-group">
              <label>Destination</label>
              <input
                type="text"
                name="destination"
                value={formData.destination}
                onChange={handleChange}
                className="form-input"
                placeholder="e.g., Paris, France"
                required
              />
            </div>
          </div>
        );
      case 2:
        return (
          <div>
            <h3 className="page-title">What type of trip?</h3>
            <div className="form-group">
              <label>Trip Type</label>
              <select
                name="trip_type"
                value={formData.trip_type}
                onChange={handleChange}
                className="form-select"
                required
              >
                <option value="">Select a type</option>
                <option value="beach">Beach Trip</option>
                <option value="adventure">Adventure Trip</option>
                <option value="cultural">Cultural Exploration</option>
                <option value="romantic">Romantic Trip</option>
              </select>
            </div>
          </div>
        );
      case 3:
        return (
          <div>
            <h3 className="page-title">When are you traveling?</h3>
            <div className="form-group">
              <label>Select Dates</label>
              <DatePicker
                selected={formData.start_date}
                onChange={handleDateChange}
                startDate={formData.start_date}
                endDate={formData.end_date}
                selectsRange
                inline
                minDate={new Date()}
                className="calendar-container"
              />
            </div>
          </div>
        );
      case 4:
        return (
          <div>
            <h3 className="page-title">Food Preference</h3>
            <div className="form-group">
              <label>Food Preference</label>
              <select
                name="food_preference"
                value={formData.food_preference}
                onChange={handleChange}
                className="form-select"
                required
              >
                <option value="vegetarian">Vegetarian</option>
                <option value="non-vegetarian">Non-Vegetarian</option>
              </select>
            </div>
          </div>
        );
      case 5:
        return (
          <div>
            <h3 className="page-title">Trip Details</h3>
            <div className="form-group">
              <label>Number of Travelers</label>
              <input
                type="number"
                name="num_members"
                value={formData.num_members}
                onChange={handleChange}
                className="form-input"
                min="1"
                required
              />
            </div>
            <div className="form-group">
              <label>Budget (INR)</label>
              <input
                type="number"
                name="budget"
                value={formData.budget}
                onChange={handleChange}
                className="form-input"
                min="1"
                required
              />
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="trip-form-container">
      <form onSubmit={handleSubmit} className="trip-form">
        {renderStep()}
        <div className="button-group">
          {step > 1 && (
            <button type="button" className="nav-button" onClick={prevStep}>
              Previous
            </button>
          )}
          {step < 5 ? (
            <button type="button" className="nav-button" onClick={nextStep}>
              Next
            </button>
          ) : (
            <button
              type="submit"
              className="submit-button"
              disabled={loading}
            >
              {loading ? 'Generating...' : 'Generate Itinerary'}
            </button>
          )}
        </div>
        {error && <p className="error-message">{error}</p>}
      </form>
    </div>
  );
};

export default TripForm;