import React, { useState } from 'react';
import TripForm from './components/TripForm';
import './App.css';
import { jsPDF } from 'jspdf';
import logo from './assets/info.webp';

const App = () => {
  const [itinerary, setItinerary] = useState(null);
  const [formData, setFormData] = useState(null);

  const handleFormSubmit = (data, form) => {
    console.log('Received itinerary data:', data);
    setItinerary(data);
    setFormData(form);
  };

  const handleDownloadPDF = () => {
    if (!itinerary || !formData) return;

    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text('Trip Itinerary', 20, 20);
    doc.setFontSize(12);
    doc.text(`Destination: ${formData.destination || 'Unknown'}`, 20, 30);
    doc.text(`Trip Type: ${formData.trip_type || 'N/A'}`, 20, 40);
    doc.text(`Budget: ₹${formData.budget}`, 20, 50);
    doc.text(`Food Preference: ${formData.food_preference || 'None'}`, 20, 60);
    doc.text(`Travelers: ${formData.num_members}`, 20, 70);
    doc.text(`Duration: ${formData.duration} days`, 20, 80);

    doc.setFontSize(14);
    doc.text('Vibe:', 20, 100);
    doc.setFontSize(12);
    doc.text(itinerary.vibe_description || 'No vibe description available', 20, 110);

    let yOffset = 120;
    doc.setFontSize(14);
    doc.text('Daily Plans:', 20, yOffset);
    itinerary.itinerary.forEach((day) => {
      yOffset += 10;
      doc.setFontSize(12);
      doc.text(`Day ${day.day}: ${day.destination}`, 20, yOffset);
      doc.text(day.description, 30, yOffset + 10);
      yOffset += 20;
      day.activities.forEach((activity) => {
        doc.text(`- ${activity}`, 30, yOffset);
        yOffset += 10;
      });
      doc.text(`Transport: ${day.transport}`, 30, yOffset);
      yOffset += 10;
      doc.text(`Tip: ${day.tip}`, 30, yOffset);
      yOffset += 10;
      doc.text('Budget:', 30, yOffset);
      Object.entries(day.daily_budget).forEach(([key, value]) => {
        yOffset += 10;
        doc.text(`${key.charAt(0).toUpperCase() + key.slice(1)}: ₹${value}`, 40, yOffset);
      });
      if (day.recommendation) {
        yOffset += 10;
        doc.text('Recommendations:', 30, yOffset);
        yOffset += 10;
        doc.text(`Stay: ${day.recommendation.stay.name} (₹${day.recommendation.stay.price})`, 40, yOffset);
        yOffset += 10;
        doc.text(`Activity: ${day.recommendation.activity.name} (₹${day.recommendation.activity.cost})`, 40, yOffset);
        yOffset += 10;
        doc.text(`Restaurant: ${day.recommendation.restaurant.name} (${day.recommendation.restaurant.dish}, ₹${day.recommendation.restaurant.price})`, 40, yOffset);
      }
      yOffset += 10;
    });

    doc.save('itinerary.pdf');
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <img src={logo} alt="Trip Generator Logo" className="app-logo" onError={(e) => console.error('Logo failed to load:', e)} />
        <h1 className="app-heading">Trip Itinerary Generator</h1>
      </header>
      <div className="content-container">
        <aside className="sidebar">
          <h2>Your Trip Details</h2>
          {formData && (
            <div className="user-details">
              <p><strong>Destination:</strong> {formData.destination || 'Not specified'}</p>
              <p><strong>Trip Type:</strong> {formData.trip_type || 'N/A'}</p>
              <p><strong>Food Preference:</strong> {formData.food_preference || 'None'}</p>
              <p><strong>Travelers:</strong> {formData.num_members}</p>
              <p><strong>Budget:</strong> ₹{formData.budget}</p>
              <p><strong>Duration:</strong> {formData.duration} days</p>
            </div>
          )}
          <div className="form-section">
            <TripForm onSubmit={handleFormSubmit} />
          </div>
        </aside>
        <main className="itinerary-section">
          {itinerary ? (
            <>
              <h2>Your Itinerary for {formData.destination}</h2>
              <p className="vibe-description"><strong>Vibe:</strong> {itinerary.vibe_description || 'No vibe description'}</p>
              {itinerary.itinerary.map((day) => (
                <div key={day.day} className="day-plan">
                  <h3>Day {day.day}: {day.destination}</h3>
                  <p>{day.description}</p>
                  <h4>Activities</h4>
                  <ul>
                    {day.activities.map((activity, index) => (
                      <li key={index}>{activity}</li>
                    ))}
                  </ul>
                  <p><strong>Transport:</strong> {day.transport}</p>
                  <p><strong>Tip:</strong> {day.tip}</p>
                  <h4>Budget</h4>
                  <ul>
                    {Object.entries(day.daily_budget).map(([key, value]) => (
                      <li key={key}>{key.charAt(0).toUpperCase() + key.slice(1)}: ₹{value}</li>
                    ))}
                  </ul>
                  {itinerary.recommendations && (
                    <>
                      <h4>Recommendations</h4>
                      <div className="recommendation">
                        <p><strong>Stay:</strong> {day.recommendation.stay.name} (₹{day.recommendation.stay.price}) - {day.recommendation.stay.description}</p>
                        <a href={day.recommendation.stay.booking_url} target="_blank" rel="noopener noreferrer">Book Stay</a>
                        <p><strong>Activity:</strong> {day.recommendation.activity.name} (₹{day.recommendation.activity.cost}) - {day.recommendation.activity.description}</p>
                        <a href={day.recommendation.activity.booking_url} target="_blank" rel="noopener noreferrer">Book Activity</a>
                        <p><strong>Restaurant:</strong> {day.recommendation.restaurant.name} ({day.recommendation.restaurant.dish}, ₹{day.recommendation.restaurant.price})</p>
                      </div>
                    </>
                  )}
                </div>
              ))}
              <button className="download-pdf-button" onClick={handleDownloadPDF} disabled={!itinerary}>
                Download PDF
              </button>
            </>
          ) : (
            <p>Fill out the form to generate your itinerary!</p>
          )}
        </main>
      </div>
    </div>
  );
};

export default App;